function siteStart() {
    if ($('horarios')) Horarios.start();
}

var Horarios = {
    start: function() {
	var horariosBlocks = $$('#horarios li');
	var horariosSlides = [];

	horariosBlocks.each(function(el, i) {
	    horariosSlides[i] = new Fx.Slide(el.getLast(), {
		duration: 500,
		transition: Fx.Transitions.Quad.easeOut,
		wait: false
	    }).hide();

	    // Activo el trigger
	    el.getFirst().addEvent('click', function(e) {
		if (horariosSlides[i].open) {
		    horariosBlocks[i].getElement('h2').addClass('ver_horario');
		    horariosBlocks[i].getElement('h2').removeClass('cerrar_horario');
		} else {
		    horariosBlocks[i].getElement('h2').addClass('cerrar_horario');
		    horariosBlocks[i].getElement('h2').removeClass('ver_horario');
		}
		horariosSlides[i].toggle();
		new Event(e).stop();
	    });
	}, this);
    }
}

window.addEvent('load', siteStart);