/*
Basado en el script site.js de mootools.net
*/
var Reserva = {
    start: function() {
	if ($('paso1')) Form.paso1();
	
	if ($('paso2')) Form.paso2();

	if ($('paso3')) Form.paso3();

	if ($('paso4')) Form.paso4();
    }
}

var Form = {
    paso1: function() {
	var trimestre = $$('#trimestre li');
	var semanas = $$('#semanas li');
	var custom_semanas = $$('#custom_semanas li');

	Form.allInputs = $$(trimestre, semanas, custom_semanas);
	Form.start();
    },

    paso2: function() {
	Form.allInputs = $$('table.horario_reserva td span');
	Form.start();
    },

    paso3: function() {
	// Primero escondemos lo que solo debe salir a falta de js
	var md = $('materia_desconocida').empty();

	var md_trigger = new Element('a', {
	    'href': '#',
	    'class': 'md_trigger',
	    'title': 'La materia que quiero reservar no se encuentra en la lista',
	    'text': 'La materia que quiero reservar no se encuentra en la lista',
	}).inject(md);

	var md_container_form;
	var md_container = new Element('div', { 'class': 'md_container' }).inject(md);
	md_container.set('slide', { 
	    duration: 1000, 
	    transition: 'cubic:out',
	    link: 'chain'
	});
	md_container.slide('hide');
	md_container.set('load', { 
	    method: 'get',
	    update: md_container,	    
	    onComplete: function(responseTree, responseElements, responseHTML, responseJS) {
		md_container_form = md_container.getElement('form');
		md_container_form.addEvent('submit', function(e) {
		    new Event(e).stop();
		    // Loading stage
		    md_container.addClass('sending_form');
		    var sending = new Element('div', {'class': 'sending_title', 'text': 'Enviando...'}).inject(md_container, 'before');

		    // Libero los errores anteriores, if any..
		    $('materia_form_dpto_error').set('text', '');
		    $('materia_form_codigo_error').set('text', '');
		    $('materia_form_nombre_error').set('text', '');

		    var request_dict = {
			'dpto': $('id_dpto').get('value'),
			'codigo': $('id_codigo').get('value'),
			'nombre': $('id_nombre').get('value'),
		    }
		    
		    new Request.JSON({
			url: md_container_form.action,
			onSuccess: function(jsonObj) {
			    // Quitting loading stage
			    sending.destroy();
			    md_container.removeClass('sending_form');
			    if (jsonObj.success) {
				// Verifico si el select box id_materia no existe y lo creo
				if ($('no_id_materia')) {
				    new Element('select', {
					'name': 'materia',
					'id': 'id_materia',
					'size': 5,
				    }).replaces($('no_id_materia'));
				}

				// Creo la nueva opcion en la lista de opciones y cierro
				new Element('option', {
				    'value': jsonObj.codigo,
				    'text': jsonObj.nombre,
				    'selected': 'selected',
				}).inject($('id_materia'));

				md_container.slide('out');
				new Fx.Scroll(window).toElement($('paso3'));
			    } else {
				$('materia_form_errors').getElement('p').set('text', 'Han ocurrido errores guardando la nueva materia:');
				if (jsonObj.dpto)
				    $('materia_form_dpto_error').set('text', jsonObj.dpto);
				if (jsonObj.codigo)
				    $('materia_form_codigo_error').set('text', jsonObj.codigo);
				if (jsonObj.nombre)
				    $('materia_form_nombre_error').set('text', jsonObj.nombre);
				var newHeight = (220
				    + $('materia_form_errors').getSize().y 
				    + $('materia_form_dpto_error').getSize().y 
				    + $('materia_form_codigo_error').getSize().y 
				    + $('materia_form_nombre_error').getSize().y + 40)
				var mdcFx = new Fx.Morph(md_container, {duration: 500});
				var mdpFx = new Fx.Morph(md_container.getParent(), {duration: 500});
				mdpFx.start({ height: newHeight });
				mdcFx.start({ height: newHeight-10 });
			    }
			}
		    }).post(request_dict);
		});
	    }
	});
	md_container.is_open = false;
	md_container.is_charged = false;

	// Seteo el trigger para que cuando se le de click abra el container.
	md_trigger.addEvent('click', function(e) {
	    new Event(e).stop();
	    if (!md_container.is_open) {
		md_container.slide('in');
		md_container.is_open = true;

		if (!md_container.is_charged) {
		    // Busco el formulario que crea una nueva materia.
		    md_container.load('/reserva/xhr/materias/agregar/');
		    md_container.is_charged = true;
		}
	    }
	    else {
		md_container.slide('out');
		md_container.is_open = false;
	    }
	});

	new Element('p', {'class': 'loading_form',
			  'text': 'Cargando el formulario'
			 }).inject(md_container);
	
    },

    paso4: function() {
	$('ingresar_profesor').set('styles', { 'display': 'none' });

	var pd_trigger = new Element('a', {
	    'href': '#',
	    'class': 'pd_trigger',
	    'title': 'El profesor que dictara este curso no se encuentra en la lista',
	    'text': 'El profesor que dictara este curso no se encuentra en la lista',
	}).inject($('soporte'), 'after');

	var pd_container_form;
	var pd_container = new Element('div', { 'class': 'pd_container' }).inject(pd_trigger, 'after');
	pd_container.set('slide', { 
	    duration: 1000, 
	    transition: 'cubic:out',
	    link: 'chain'
	});
	pd_container.slide('hide');
	pd_container.set('load', { 
	    method: 'get',
	    update: pd_container,	    
	    onComplete: function(responseTree, responseElements, responseHTML, responseJS) {
		pd_container_form = pd_container.getElement('form');
		pd_container_form.addEvent('submit', function(e) {
		    new Event(e).stop();
		    // Loading stage
		    pd_container.addClass('sending_form');
		    var sending = new Element('div', {'class': 'sending_title', 'text': 'Enviando...'}).inject(pd_container, 'before');

		    // Libero los errores anteriores, if any..
		    $('prof_form_ci_error').set('text', '');
		    $('prof_form_nombre_error').set('text', '');
		    $('prof_form_email_error').set('text', '');
		    $('prof_form_dpto_error').set('text', '');
		    $('prof_form_telefono_error').set('text', '');
		    $('prof_form_oficina_error').set('text', '');

		    var request_dict = {
			'ci': $('id_ci').get('value'),
			'nombre': $('id_nombre').get('value'),
			'email': $('id_email').get('value'),
			'dpto': $('id_dpto').get('value'),
			'telefono': $('id_telefono').get('value'),
			'oficina': $('id_oficina').get('value'),
		    }
		    
		    new Request.JSON({
			url: pd_container_form.action,
			onSuccess: function(jsonObj) {
			    // Quitting loading stage
			    sending.destroy();
			    pd_container.removeClass('sending_form');
			    if (jsonObj.success) {
				// Verifico si el select box id_profesor no existe y lo creo
				if ($('no_id_profesor')) {
				    new Element('select', {
					'name': 'profesor',
					'id': 'id_profesor',
					'size': 5,
				    }).replaces($('no_id_profesor'));
				}

				// Creo la nueva opcion en la lista de opciones y cierro
				new Element('option', {
				    'value': jsonObj.pk,
				    'text': 'Prof. ' + jsonObj.nombre,
				    'selected': 'selected',
				}).inject($('id_profesor'));
				pd_container.slide('out');
				new Fx.Scroll(window).toElement($('paso4'));
			    } else {
				$('prof_form_errors').getElement('p').set('text', 'Han ocurrido errores guardando el nuevo profesor');
				if (jsonObj.dpto)
				    $('prof_form_dpto_error').set('text', jsonObj.dpto);
				if (jsonObj.email)
				    $('prof_form_email_error').set('text', jsonObj.email);
				if (jsonObj.nombre)
				    $('prof_form_nombre_error').set('text', jsonObj.nombre);
				if (jsonObj.ci)
				    $('prof_form_ci_error').set('text', jsonObj.ci);
				if (jsonObj.telefono)
				    $('prof_form_telefono_error').set('text', jsonObj.telefono);
				if (jsonObj.oficina)
				    $('prof_form_oficina_error').set('text', jsonObj.oficina);
				var newHeight = (375
						 + $('prof_form_ci_error').getSize().y
						 + $('prof_form_nombre_error').getSize().y
						 + $('prof_form_email_error').getSize().y
						 + $('prof_form_dpto_error').getSize().y
						 + $('prof_form_telefono_error').getSize().y
						 + $('prof_form_oficina_error').getSize().y
						 + 80)
				var mdcFx = new Fx.Morph(pd_container, {duration: 500});
				var mdpFx = new Fx.Morph(pd_container.getParent(), {duration: 500});
				mdpFx.start({ height: newHeight });
				mdcFx.start({ height: newHeight-10 });
			    }
			}
		    }).post(request_dict);
		});
	    }
	});
	pd_container.is_open = false;
	pd_container.is_charged = false;

	// Seteo el trigger para que cuando se le de click abra el container.
	pd_trigger.addEvent('click', function(e) {
	    new Event(e).stop();
	    if (!pd_container.is_open) {
		pd_container.slide('in');
		pd_container.is_open = true;

		if (!pd_container.is_charged) {
		    // Busco el formulario que crea un nuevo profesor.
		    pd_container.load('/reserva/xhr/profesor/agregar/');
		    pd_container.is_charged = true;
		}
	    }
	    else {
		pd_container.slide('out');
		pd_container.is_open = false;
	    }
	});

	new Element('p', {'class': 'loading_form',
			  'text': 'Cargando el formulario'
			 }).inject(pd_container);
    },

    start: function() {
	Form.fxs = [];

	Form.allInputs.each(function(input) {
	    input.inputElement = input.getElement('input');
	    input.inputElement.setStyle('display', 'none');

	    input.parentElement = input.getParent();
	});

	Form.parse();

	Form.allInputs.each(function(input) {
	    if (input.inputElement.checked) Form.select(input);
	});
    },

    select: function(input) {
	input.inputElement.checked = 'checked';
	
	if (input.inputElement.type == 'radio') input.addClass('selected');
	else if (input.inputElement.type == 'checkbox') input.addClass('checked');

	// Verifico si es un input type radio, y si es asi, tengo ke
	// des-seleccionar los otros elementos
	if (input.inputElement.type == 'radio') {
	    input.parentElement.getChildren('li').each(function(other) {
		if (input != other && !other.inputElement.disabled) Form.deselect(other);
	    });
	}
    },

    deselect: function(input) {
	input.inputElement.checked = false;
	
	Form.fxs[input.index].start({
	    'color': '#000'
	});

	input.removeClass('selected');
	input.removeClass('checked');
    },

    parse: function() {
	Form.allInputs.each(function(input, i) {
	    input.index = i;
	    if (!input.inputElement.disabled) {
		Form.fxs[i] = new Fx.Morph(input, {wait: false, duration: 300});
		
		input.addEvent('click', function() {
		    if (input.inputElement.type == 'radio' && !input.hasClass('selected')) Form.select(input); // radios
		    else if (input.inputElement.type == 'checkbox') { // checks
			if (input.hasClass('checked')) Form.deselect(input);
			else Form.select(input);
		    }
		});
		
		input.addEvent('mouseenter', function() {
		    if (!input.hasClass('selected')) {
			Form.fxs[i].start({
			    'color': '#2ac3fc'
			}); // Me puedo poner mas creativo
		    }
		});
		
		input.addEvent('mouseleave', function() {
		    if (!input.hasClass('selected') && !input.hasClass('checked')) {
			Form.fxs[i].start({
			    'color': '#000'
			});
		    }
		});
	    } else input.addClass('disabled');
	});
    }
};

window.addEvent('load', Reserva.start);