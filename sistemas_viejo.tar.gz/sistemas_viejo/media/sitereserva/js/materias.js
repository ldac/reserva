function siteStart() {
    if ($('materias_list')) Materias.start();
    if ($('atras')) Materias.goBack();
}

var Materias = {
    start: function() {
	var materiasBlocks = $$('#materias_list li');
	var toColor = '#E0E0E0';
	var fromColor;

	materiasBlocks.each(function(el) {
	    var hoverFx = new Fx.Tween(el, {
		duration: 210,
		wait: false
	    });

	    el.addEvent('mouseenter', function(e) {
		hoverFx.start('background-color', toColor);
	    });

	    el.addEvent('mouseleave', function(e) {
		if (el.hasClass('odd')) { fromColor = '#EBEBEB'; }
		else { fromColor = '#EFEFEF'; }
		hoverFx.start('background-color', fromColor);
	    });
	});
    },

    goBack: function() {
	$('atras').addEvent('click', function(e) {
	    new Event(e).stop();
	    history.back();
	});
    }
}

window.addEvent('load', siteStart);