/*
Manejador principal de la aplicaci�n BugReports
para Django.

Autor: Daniel Barreto N. <daniel@ac.labf.usb.ve>
Fecha ult. modificacion: 24/06/08
*/

var BugReport = {
    start: function() {
	BugReport.form = $('bugreport_form');
	BugReport.responseBlock = $('bugreport_response');
	
	BugReport.form.addEvent('submit', function(e) {
	    // Prevent the submit event
	    new Event(e).stop();

	    BugReport.responseBlock.empty().addClass('loading').set('text', 'Enviando...');

	    var request_dict = {}
	    BugReport.form.getElements('input, select, textarea').each(function (el) {
		request_dict[el.name] = el.get('value');
	    });

	    var req = new Request.JSON({
		url: this.getProperty('action'),
		onSuccess: function(jsonObj) {
		    BugReport.process_response(jsonObj);
		}
	    }).post(request_dict);
	});
    },

    process_response: function(jsonObj) {
	BugReport.responseBlock.empty().removeClass('loading');
	if (jsonObj.success) {
	    BugReport.responseBlock.set('text', 'Bug enviado correctamente! Gracias por su colaboracion.');

	    (function () {
		BugReport.responseBlock.empty();
	    }).delay(7000);
	}
	else {
	    jsonHash = new Hash(jsonObj);
	    BugReport.show_errors(jsonHash);
	}
    },

    show_errors: function(jsonHash) {
	BugReport.responseBlock.addClass('error').set('text','Ocurri� el siguiente error:');

	if (jsonHash.has('bug_comment'))
	    BugReport.show_error(jsonHash.bug_comment, $('bugreport_comment_error'));
	if (jsonHash.has('email'))
	    BugReport.show_error(jsonHash.email, $('bugreport_email_error'));

	(function () {
	    BugReport.responseBlock.empty();
	    $('bugreport_comment_error').empty();
	    $('bugreport_email_error').empty();
	    BugReport.responseBlock.removeClass('error');
	}).delay(7000); // Despues de 7 seg limpio los errores
    },

    show_error: function(error, block) {
	block.set('text', error);
    }
}

window.addEvent('domready', BugReport.start);