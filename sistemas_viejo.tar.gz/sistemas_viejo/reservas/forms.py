# -*- coding: utf-8 -*-

from django.forms import ModelForm
from utils import validate_unique
from reservas.models import Reserva
from reservas.models import SolicitudPermiso

class ReservaForm(ModelForm):
    def clean_ci(self):
        if 1000000 < self.cleaned_data['ci'] < 40000000:
            return self.cleaned_data['ci']
        else:
            raise ValidationError(u'Introduzca una cedula válida')
    class Meta:
        model = Reserva

class SolicitudForm(ModelForm):
    class Meta:
        model = SolicitudPermiso
validate_unique.enhance_form(SolicitudForm, SolicitudPermiso)
