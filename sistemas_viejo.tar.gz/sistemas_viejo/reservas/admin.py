from django.contrib import admin
from models import Reservador, SolicitudPermiso, Reserva

class ReservadorAdmin(admin.ModelAdmin):
    pass

class SolicitudPermisoAdmin(admin.ModelAdmin):
    pass

class ReservaAdmin(admin.ModelAdmin):
    pass

admin.site.register(Reservador, ReservadorAdmin)
admin.site.register(SolicitudPermiso, SolicitudPermisoAdmin)
admin.site.register(Reserva, ReservaAdmin)
