from django.template import TemplateSyntaxError, Node, Library, resolve_variable, loader
from django.core.exceptions import ObjectDoesNotExist
from sistemas.salas.models import Sala
from sistemas.universidad.models import Materia
from sistemas.reservas.models import Reserva
from sistemas.utils.views.commons import obtener_trimestre

register = Library()

class EliminarReservaNode(Node):
    def __init__(self, codigo, sala, trimestre):
        self.codigo = codigo
        self.sala = sala
        self.trimestre = trimestre

    def render(self, context):
        # Recupero el codigo de la materia y el nombre de la sala
        self.codigo_materia = resolve_variable(self.codigo, context)
        self.nombre_sala = resolve_variable(self.sala, context)

        # Si es necesario recupero el trimestre.
        if not self.trimestre == 'actual' and not self.trimestre == 'siguiente':
            self.trimestre = resolve_variable(self.trimestre, context)
            
        try:
            sala = Sala.objects.get(nombre__exact=self.nombre_sala)
        except ObjectDoesNotExist:
            return 'Nombre de sala invalido'
        if not sala.reservable:
            return 'La sala %s no tiene horario disponible' % self.nombre_sala

        try:
            materia = Materia.objects.get(codigo__exact=self.codigo_materia)
        except ObjectDoesNotExist:
            return 'Codigo de materia invalido'

        # Busco los datos de horario para la semana y la sala
        context['horario'] = Reserva.objects.para_eliminar_materia(sala=sala, materia=materia, trimestre=self.trimestre)
        context['trimestre'], context['sala'], context['materia'] = self.trimestre, sala, materia
        # Busco el template a renderizar
        template = 'sitereserva/desreservar/tabla.html'

        tabla_horario = loader.get_template(template)
        output = tabla_horario.render(context)

        return output


class EliminarReserva:
    """
    Modo de uso:
    {% eliminar_reserva de materia codigo_materia en sala nombre_sala trimestre actual_o_siguiente%}
    """
    def __call__(self, parser, token):
        tokens = token.split_contents()
        if len(tokens) != 9:
            raise TemplateSyntaxError, "%r tag requires exactly 8 arguments" % tokens[0]
        if tokens[1] != 'de':
            raise TemplateSyntaxError, "First argument in %r tag must be 'de'" % tokens[0]
        if tokens[2] != 'materia':
            raise TemplateSyntaxError, "Second argument in %r tag must be 'materia'" % tokens[0]

        # Se asumira que el cuarto token es una variable que dice el
        # codigo de la materia
        cod = tokens[3]

        if tokens[4] != 'en':
            raise TemplateSyntaxError, "Fourth argument in %r tag must be 'en'" % tokens[0]
        if tokens[5] != 'sala' and tokens[4] != 'semanas':
            raise TemplateSyntaxError, "Fifth argument in %r tag must be 'sala'" % tokens[0]

        ## Se asumira que el tercer token es una variable que dice el
        ## nombre de la sala
        sala = tokens[6]

        if tokens[7] != 'trimestre':
            raise TemplateSyntaxError, "Seventh argument in %r tag must be 'trimestre'" % tokens[0]
        trimestre = tokens[8]

        return EliminarReservaNode(cod, sala, trimestre)

register.tag('eliminar_reserva', EliminarReserva())
