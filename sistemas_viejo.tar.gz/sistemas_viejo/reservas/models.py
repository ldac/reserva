# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from universidad.models import Departamento, Materia, Profesor
from salas.models import Sala
from utils.views.commons import obtener_trimestre

WEEK_DAYS = (
    ('1', u'Lunes'),
    ('2', u'Martes'),
    ('3', u'Miércoles'),
    ('4', u'Jueves'),
    ('5', u'Viernes'),
    )

STATUS_SOLIC = (
    ('-1', 'Espera confirmacion'),
    ('0', 'Rechazada'),
    ('1', 'Aceptada'),
    ('2', 'Dudosa'),
    )

class ReservadorManager(models.Manager):
    def obtener_materias(self, username):
        try:
            reservador = self.get_query_set().get(djuser__username__exact=username)
        except ObjectDoesNotExist:
            return []
        reservas = Reserva.objects.filter(reservador=reservador)
        materias = []
        for r in reservas:
            materias.append(r.materia)
        return list(set(materias))
    
    def obtener_materias_de_dpto(self, username):
        try:
            reservador = self.get_query_set().get(djuser__username__exact=username)
        except ObjectDoesNotExist:
            return []
        if reservador.super_reservador:
            return Materia.objects.all()
        return Materia.objects.filter(dpto__pk__exact=reservador.dpto_id)


class ReservaManager(models.Manager):
    def para_horario(self, sala, semana, dia='todos', trimestre='actual'):
        """
        Devuelve la estructura sobre la cual se itera para escribir el horario
        La estructura es de la forma:
        [
        (1, [materia, False, False, materia, False])
        (2, [...]),
        ...
        ]
        Donde los indices de las tuplas representan una hora de la universidad,
        y las listas de 5 elementos representan las reservas que se dan los 5 dias
        de clases regulares, empezando desde el lunes, para la hora de la tupla.

        En caso de que se haya pedido solo un dia en especifico, se devuelve
        el query_set indicado.
        """
        trimestre = obtener_trimestre(trimestre)
        if dia == 'todos':
            semanas = semana.split('-')
            horario = []
            for hora in range(1,13):
                materias = [False, False, False, False, False]
                for semana in semanas:
                   reservas = self.get_query_set().filter(sala=sala, semana=semana, hora=hora, trimestre=trimestre, habilitada=True).order_by('dia')
                   for reserva in reservas:
                       materias[reserva.dia-1] = reserva.materia
                    
                horario.append((hora, materias))
                
            return horario
        else:
            for day in WEEK_DAYS:
                if day[1] == dia.capitalize():
                    dia = day[0]
            if dia.isdigit():
                return self.get_query_set().filter(sala=sala, semana=semana, dia=dia, trimestre=trimestre, habilitada=True).order_by('hora', 'dia')
            else:
                return []

    def para_eliminar_materia(self, sala, materia, trimestre='actual'):
        """
        De igual forma que el metodo 'para_horario', devuelve la estructura sobre
        la cual se itera para escribir un horario en donde solo salen las horas
        reservadas para dictar la materia pasada por parametro.

        Esta estructura representara la union de todas las horas que se da la
        materia en todas las semanas del trimestre.
        """
        trimestre = obtener_trimestre(trimestre)
        reservas = Reserva.objects.filter(sala = sala, trimestre = trimestre, materia = materia, habilitada = True).order_by('hora', 'dia')
        horario = []

        for hora in range(1,13):
            materias = [False, False, False, False, False]
            clasesxhora = list(set([clase for clase in reservas if clase.hora == hora]))
            for clase in clasesxhora:
                materias[int(clase.dia) - 1] = clase

            horario.append((hora, materias))

        return horario

    def profesores_que_dictan(self, materia):
        reservas = self.get_query_set().filter(materia=materia)
        profesores = []
        for r in reservas:
            if r.profesor:
                profesores.append(r.profesor)
        return list(set(profesores))

class SolicitudManager(models.Manager):
    def get_by_status(self, status):
        status_dict = {
            'en_espera': '-1',
            'rechazadas': '0',
            'aceptadas': '1',
            'dudosas': '2'
            }
        if status in status_dict:
            return self.get_query_set().filter(status__exact=status_dict[status])
        elif status == 'todas':
            return self.get_query_set()
        return []
            

# Status super-reservador: te deja reservar materias de cualquier
# carrera o departamento
class Reservador(models.Model):
    djuser = models.ForeignKey(User, unique=True)
    ci = models.IntegerField(max_length=8, unique=True)
    dpto = models.ForeignKey(Departamento)
    oficina = models.CharField(max_length=15, blank=True)
    telefono = models.CharField(blank=True, max_length=12)
    super_reservador = models.BooleanField(default=False) # if True, puede reservar materias de cualquier departamento
    objects = ReservadorManager()
    # Para llevar un registro de los reservadores, descomentar
    register_date = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return "%s" % self.djuser.username

    class Meta:
        verbose_name_plural = "Reservadores"


class SolicitudPermiso(models.Model):
    ci = models.IntegerField(max_length=8, unique=True)
    login = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=20)
    apellido = models.CharField(max_length=30)
    dpto = models.ForeignKey(Departamento)
    oficina = models.CharField(max_length=15, blank=True)
    telefono = models.CharField(blank=True, max_length=12)
    email = models.EmailField(help_text=u'Se requiere un email válido, un mensaje de confirmación será enviado al mismo')
    comentario = models.TextField(blank=True)
    status = models.IntegerField(max_length=1, choices=STATUS_SOLIC, editable=False, default='-1')
    # Para llevar un registro de las solicitudes, descomentar
    submit_date = models.DateTimeField(auto_now_add=True)
    #ip_address = models.IPAddressField(editable=False) # has to be auto_populated. (not still) 
    objects = SolicitudManager()

    def __unicode__(self):
        return 'SOLICITUD: %s' % self.login

    def get_status(self):
        for tupla in STATUS_SOLIC:
            if int(tupla[0]) == int(self.status):
                return tupla[1]
        return ''

    class Meta:
        verbose_name = "Solicitud"
        verbose_name_plural = "Solicitudes"


class Reserva(models.Model):
    materia = models.ForeignKey(Materia)
    seccion = models.PositiveIntegerField(max_length=2)
    reservador = models.ForeignKey(Reservador)
    sala = models.ForeignKey(Sala)
    profesor = models.ForeignKey(Profesor, blank=True, null=True)
    # Horario
    trimestre = models.CharField(max_length=12)
    semana = models.IntegerField(max_length=2)
    dia = models.IntegerField(max_length=1, choices=WEEK_DAYS)
    hora = models.IntegerField(max_length=1)
    # Para llevar un registro de las reservas, descomentar
    submit_date = models.DateTimeField(auto_now_add=True)
    # - Para llevar registro de TODAS las reservas
    habilitada = models.BooleanField(editable=False, default=True)
    objects = ReservaManager()

    def obtener_dia(self):
        return WEEK_DAYS[self.dia - 1][1]

    def __unicode__(self):
        return '(%s) %s-Sem%s, hora %s' % (self.trimestre, self.obtener_dia(), self.semana, self.hora)

    # Chequeo unicidad de la reserva, tupla: trimestre,semana,dia,hora
    class Meta:
        unique_together=(("trimestre", "semana", "dia", "hora", "sala"),)
        permissions = (
            ('can_reserve', 'Puede reservar las salas'),
            ('can_dereserve', 'Puede desreservar las salas'),
            )
