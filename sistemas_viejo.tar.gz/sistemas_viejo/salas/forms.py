from django.forms import ModelForm
from salas.models import SolicitudSoftware
from utils import validate_unique

class SolicitudSoftwareForm(ModelForm):
    class Meta:
        model = SolicitudSoftware

validate_unique.enhance_form(SolicitudSoftwareForm, SolicitudSoftware)
