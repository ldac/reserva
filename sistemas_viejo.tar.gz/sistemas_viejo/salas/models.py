from django.db import models
from django.contrib.auth.models import User
from universidad.models import Materia

OS_CHOICES = (
    ('l', 'GNU/Linux'),
    ('w', 'Windows XP'),
    ('b', 'Ambos'),
    )

SOLSOF_CHOICES = (
    ('A', 'Aceptado'),
    ('D', 'Denegado'),
    ('P', 'Pending'),
    )

class SoftwareManager(models.Manager):
    def get_linux_software(self):
        return self.get_query_set().filter(os='l')
    def get_windows_software(self):
        return self.get_query_set().filter(os='w')
    def get_both_software(self):
        return self.get_query_set().filter(os='b')

class Software(models.Model):
    nombre = models.CharField(max_length=50)
    os = models.CharField(max_length=1, choices=OS_CHOICES)
    licencia = models.CharField(blank=True, max_length=50)
    website = models.URLField(max_length=300, blank=True)
    version = models.CharField(max_length=10, blank=True)
    descripcion = models.TextField(blank=True)
    objects = SoftwareManager()

    def __unicode__(self):
        return '%s' % self.nombre

    class Meta:
        verbose_name_plural = "Software"


class SalaManager(models.Manager):
    def obtener_reservables(self):
        return self.get_query_set().filter(reservable=True)

class Sala(models.Model):
    nombre = models.CharField(max_length=40, unique=True)
    direccion = models.CharField(max_length=7)
    software = models.ManyToManyField(Software)
    reservable = models.BooleanField();
    privada = models.BooleanField();
    photo = models.ImageField(upload_to='images/salas/', blank=True)
    objects = SalaManager()

    def __unicode__(self):
        return 'Sala %s' % self.nombre
    def software_linux(self):
        return self.software.filter(os='l')
    def software_windows(self):
        return self.software.filter(os='w')
    def software_both(self):
        return self.software.filter(os='b')
    
    
# Hay que chequear que las reservas las haga un reservador!
class SolicitudSoftware(models.Model):
    reservador = models.ForeignKey(User)
    materia = models.ForeignKey(Materia)
    nombre = models.CharField(max_length=50, unique=True)
    os = models.CharField(max_length=1, choices=OS_CHOICES)
    licencia = models.CharField(blank=True, max_length=50)
    website = models.URLField(max_length=300, blank=True)
    version = models.CharField(max_length=10, blank=True)
    descripcion = models.TextField(blank=True)
    status = models.CharField(max_length=1, choices=SOLSOF_CHOICES, default='P', blank=True)
    ip_address = models.IPAddressField() # make it Auto-populated...
    submit_date = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return 'SOLICITUD_SOFTWARE: %s - %s' % (self.reservador, self.nombre)

    class Admin:
        pass
    class Meta:
        verbose_name = 'Solicitud de Software'
        verbose_name_plural = 'Solicitudes de Software'
