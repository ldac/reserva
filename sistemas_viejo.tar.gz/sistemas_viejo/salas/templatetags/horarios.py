from django.template import TemplateSyntaxError, Node, Library, resolve_variable, loader
from django.core.exceptions import ObjectDoesNotExist
from sistemas.salas.models import Sala
from sistemas.reservas.models import Reserva
from sistemas.utils.views.commons import obtener_trimestre

register = Library()

class TablaHorarioNode(Node):
    def __init__(self, sala, sem, sem_lookup_var, trimestre, reservar):
        self.sala = sala
        self.sem_lookup_var = sem_lookup_var
        self.sem = sem
        self.trimestre = trimestre
        self.reservar = reservar

    def render(self, context):
        # Recupero el nombre de la sala
        self.nombre_sala = resolve_variable(self.sala, context)
        if self.sem_lookup_var is not None:
            self.semana = resolve_variable(self.sem_lookup_var, context)
            if isinstance(self.semana, int):
                self.semana = str(self.semana)
        else:
            self.semana = self.sem
        if not self.trimestre == 'actual' and not self.trimestre == 'siguiente':
            self.trimestre = resolve_variable(self.trimestre, context)
        try:
            s = Sala.objects.get(nombre__exact=self.nombre_sala)
        except ObjectDoesNotExist:
            return 'Nombre de sala invalido'
        if not s.reservable:
            return 'La sala %s no tiene horario disponible' % self.nombre_sala

        # Busco los datos de horario para la semana y la sala
        context['horario'] = Reserva.objects.para_horario(sala=s, semana=self.semana, trimestre=self.trimestre)
        context['trimestre'], context['sala'], context['semana'] = self.trimestre, s, self.semana
        # Busco el template a renderizar
        template = 'salas/tabla_horario.html'
        if self.reservar:
            template = 'salas/tabla_reserva.html'
        tabla_horario = loader.get_template(template)
        output = tabla_horario.render(context)

        return output

class TrimestreNode(Node):
    def __init__(self, trimestre):
        self.trimestre = trimestre

    def render(self, context):
        return obtener_trimestre(self.trimestre)



class TablaHorario:
    """
    Modo de uso:
    {% imprimir_horario para nombre_sala en semana num_semana %}
    o
    {% imprimir_horario para nombre_sala en semana num_semana siguiente trimestre %}
    """
    def __call__(self, parser, token):
        tokens = token.split_contents()
        if len(tokens) != 8:
            raise TemplateSyntaxError, "%r tag requires exactly 7 arguments" % tokens[0]
        if tokens[1] != 'para':
            raise TemplateSyntaxError, "First argument in %r tag must be 'para'" % tokens[0]
        # Buscamos la sala
        ## salas_reservables = Sala.objects.obtener_reservables()
##        if tokens[2] not in salas:
##             raise TemplateSyntaxError, "%r tag don't represent a valid Sala" % tokens[2]

        ## Se asumira que el tercer token es una variable que dice el
        ## nombre de la sala
        sala = tokens[2]
        if tokens[3] != 'en':
            raise TemplateSyntaxError, "Thirth argument in %r tag must be 'en'" % tokens[0]
        if tokens[4] != 'semana' and tokens[4] != 'semanas':
            raise TemplateSyntaxError, "Fourth argument in %r tag must be 'semana' or 'semanas'" % tokens[0]

        sem_lookup_var, sem = None, None
        if tokens[5].isdigit():
            if int(tokens[5]) not in SEMANAS:
                raise TemplateSyntaxError, "Week number must be between %s and %s" % (SEMANAS[0], SEMANAS[-1])
            sem = tokens[5]
        else:
            sem_lookup_var = tokens[5]

        if tokens[6] != 'trimestre':
            raise TemplateSyntaxError, "Sixth argument in %r tag must be 'trimestre'" % tokens[0]
        trimestre = tokens[7]

        # Por ultimo vemos si el tag pedido es para imprimir o para reservar
        reservar = False
        if tokens[0] == 'reservar_horario':
            reservar = True
        return TablaHorarioNode(sala, sem, sem_lookup_var, trimestre, reservar)

class Trimestre:
    def __call__(self, parser, token):
        try:
            tag, trimestre = token.split_contents()
        except ValueError:
            raise TemplateSyntaxError, "trimestre tag takes exactly 2 arguments"
        if trimestre != 'actual' and trimestre != 'siguiente':
            raise TemplateSyntaxError, "Second argument in %r tag must be either 'actual' or 'siguiente'" % tag
        return TrimestreNode(trimestre)

register.tag('imprimir_horario', TablaHorario())
register.tag('reservar_horario', TablaHorario())
register.tag('trimestre', Trimestre())
