from django.contrib import admin
from salas.models import Software, Sala, SolicitudSoftware

class SoftwareAdmin(admin.ModelAdmin):
    pass

class SalaAdmin(admin.ModelAdmin):
    filter_horizontal = ['software']

class SolicitudSoftwareAdmin(admin.ModelAdmin):
    pass

admin.site.register(Software, SoftwareAdmin)
admin.site.register(Sala, SalaAdmin)
admin.site.register(SolicitudSoftware, SolicitudSoftwareAdmin)
