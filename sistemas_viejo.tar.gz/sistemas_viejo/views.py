from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.contrib.auth import authenticate, login, logout

def inicio(request):
    return render_to_response('inicio.html', locals(), context_instance=RequestContext(request))

def login_and_return(request):
    if not request.POST:
        return HttpResponseRedirect(request.META['HTTP_REFERER'])
    uname, passwd = request.POST['username'], request.POST['password']
    user = authenticate(username=uname, password=passwd)
    if user is not None:
        if user.is_active:
            login(request, user)
            return HttpResponseRedirect(request.path)
        else:
            dict_response = {'message': 'Cuenta desabilitada'}
    else:
        dict_response = {'message': 'Nombre de usuario o contrasena incorrectas'}

    #if request.is_ajax:
    return render_to_response('simple_message.html', dict_response)


def logout_and_return(request):
    logout(request)
    return HttpResponseRedirect(request.META['HTTP_REFERER'])
