from bug_reports.forms import BugReportForm

def bugs_form(request):
    return { 'bugreport_form': BugReportForm() }
