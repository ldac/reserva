from utils.views.generics import create_with_json
from django.views.decorators.http import require_POST
from bug_reports.models import BugReport
from bug_reports.forms import BugReportForm

@require_POST
def bug_report_post(request):
    # creo el diccionario que va a reemplazar a request.POST
    post_dict = {
        'email': request.POST.get('email', ''),
        'bug_comment': request.POST.get('bug_comment', False),
        'report_path': request.META['HTTP_REFERER'],
        'report_ip_address': request.META['REMOTE_ADDR'],
        # Recuerda borrar esta despues de lograr un nuevo syncdb
        'status': 'P',
        }
    if request.user.is_authenticated():
        post_dict['reporter'] = request.user.pk
        post_dict['email'] = request.user.email
    return create_with_json(request, model=BugReport, newform_class=BugReportForm,
                            post_save_redirect=request.META['HTTP_REFERER'],
                            post_replace_dict=post_dict, return_success_json=True,
                            form_object_name='br')
