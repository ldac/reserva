from django.contrib import admin
from bug_reports.models import BugReport

class BugReportAdmin(admin.ModelAdmin):
    pass
admin.site.register(BugReport, BugReportAdmin)
