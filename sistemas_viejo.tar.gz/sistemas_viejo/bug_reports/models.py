# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth.models import User

REPORT_STATUS = (
    ('P', 'Pending'),
    ('F', 'Fixed'),
    ('W', "Won't Fix"),
    )

class BugReport(models.Model):
    submit_date = models.DateTimeField(auto_now_add=True)
    reporter = models.ForeignKey(User, blank=True, null=True)
    email = models.EmailField(blank=True, null=True, help_text=u'Si quiere recibir\
    respuesta acerca del bug que esta posteando, puede dejarnos su email')
    bug_comment = models.TextField(help_text=u'Por favor describa detalladamente\
    el error. Si el error no lo vio en la página donde usted se encuentra\
    actualmente, indíquelo.')
    status = models.CharField(max_length=1, choices=REPORT_STATUS, default='P')
    reply = models.TextField(blank=True)
    replied = models.BooleanField(editable=False, default=False)
    report_path = models.CharField(max_length=100)
    report_ip_address = models.IPAddressField()

    def __unicode__(self):
        return "BUG: (%s) %s..." % (self.reporter, self.bug_comment[:10])
    
    class Meta:
        verbose_name = "Reporte de Bug"
        verbose_name_plural = "Reportes de Bugs"
