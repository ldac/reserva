from django.forms import ModelForm
from bug_reports.models import BugReport

class BugReportForm(ModelForm):
    class Meta:
        model = BugReport
