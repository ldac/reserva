from django.conf.urls.defaults import *
from django.views.generic.simple import direct_to_template
from django.views.generic.list_detail import object_list
from utils.commons import SEMANAS
from utils.views.generics import create_with_json
from bug_reports.views import bug_report_post
from sitereserva.views import posting, simple_views, xhr_requests
from salas.models import Sala
from universidad.models import Materia

materias_dict = {
    'queryset': Materia.objects.all().order_by('nombre'),
    'template_name': 'sitereserva/materias_list.html',
    'template_object_name': 'materias',
    'paginate_by': 10
    }
salas_dict = {
    'queryset': Sala.objects.obtener_reservables().order_by('nombre'),
    'template_name': 'sitereserva/salas_list.html',
    'template_object_name': 'salas'
    }

urlpatterns = patterns('',
                       url(r'^$', simple_views.inicio, name='inicio'),
                       (r'^login/$', 'django.contrib.auth.views.login', {'template_name': 'sitereserva/login.html'}, 'login_reserva'),
                       (r'^password_change/$', 'django.contrib.auth.views.password_change', {'template_name': 'sitereserva/change_password.html'}, 'password_change'),
                       (r'^password_change/done/$', 'django.contrib.auth.views.password_change_done', {'template_name': 'sitereserva/change_password_done.html'}, 'password_change_done'),
                       
                       (r'^horarios/$', simple_views.horarios),
                       (r'^horarios/sala(?P<sala>[\w\ ]{1,20})/semana(?P<semana>[2-9]|10|11|12)/$', direct_to_template, {'template': 'sitereserva/horarios_detail.html', 'trimestre': 'actual'}, 'horario_actual'),
                       (r'^horarios/sala(?P<sala>[\w\ ]{1,20})/todas/$', direct_to_template, {'template': 'sitereserva/horarios_detail.html', 'trimestre': 'actual', 'semanas': SEMANAS}, 'horario_actual_todas'),
                       (r'^horarios/siguiente/sala(?P<sala>[\w\ ]{1,20})/semana(?P<semana>[2-9]|10|11|12)/$', direct_to_template, {'template': 'sitereserva/horarios_detail.html', 'trimestre': 'siguiente'}, 'horario_siguiente'),
                       (r'^horarios/siguiente/sala(?P<sala>[\w\ ]{1,20})/todas/$', direct_to_template, {'template': 'sitereserva/horarios_detail.html', 'trimestre': 'siguiente', 'semanas': SEMANAS}, 'horario_siguiente_todas'),
                       
                       (r'^materias/$', object_list, materias_dict, 'materias_index'),
                       (r'^materias/pagina(?P<page>\d+)/$', object_list, materias_dict, 'materias_list_paginated'),
                       (r'^materias/detalles/(?P<codigo>\w{4,6})/$', simple_views.materias_detail),

                       (r'^salas/$', object_list, salas_dict, 'salas_index'),
                       (r'^salas/software_disponible/sala(?P<nombre>[\w\ ]{1,20})/$', simple_views.software_disponible),
                       (r'^salas/software_disponible/solicitar/$', posting.solicitar_software),
                       (r'^salas/software_disponible/solicitar/finalizado/$', direct_to_template, {'template': 'sitereserva/software_finalizado.html'}, 'solicitar_software_finalizado'),
                       
                       url(r'^reservar/$', posting.reserva_form, name='reservar'),
                       url(r'^reservar/paso(?P<paso>[2-4])/$', posting.reserva_form, name='reservar_con_paso'),
                       url(r'^reservar/validacion/$', posting.validar_reserva, name='reservar_validacion'),
                       url(r'^reservar/reserva_finalizada/$', posting.reserva_finalizada, name='reservar_finalizado'),

                       url(r'^eliminar_reserva/$', posting.desreservar, name='eliminar_reserva'),
                       url(r'^eliminar_reserva/paso(?P<paso>[2-4])/', posting.desreservar, name='eliminar_reserva_con_paso'),
                       url(r'^eliminar_reserva/validacion/', posting.desreservar_validacion, name='validacion_eliminar_reserva'),
                       url(r'^eliminar_reserva/finalizado/$', posting.desreservar_finalizado, name='eliminar_reserva_finalizado'),

                       url(r'^solicitud/hacer/', posting.hacer_solicitud_permiso, name='hacer_solicitud'),
                       (r'^solicitud/confirmar/', direct_to_template, {'template': 'sitereserva/solicitud/confirmacion.html'}),
                       url(r'^solicitud/ver/$', simple_views.solicitudes_list, name='solicitudes_index'),
                       url(r'^solicitud/ver_(?P<status>en_espera|rechazadas|dudosas|aceptadas|todas)/$', simple_views.solicitudes_list, name='solicitudes_list_by'),
                       url(r'^solicitud/ver/(?P<object_id>\d+)/$', simple_views.solicitudes_detail, name='solicitud_detail'),
                       url(r'^solicitud/procesar/$', posting.solicitudes_procesar, name='solicitudes_procesar'),

                       url(r'^xhr/materias/agregar/$', xhr_requests.agregar_materia, name='xhr_agregar_materia'),
                       url(r'^xhr/profesor/agregar/$', xhr_requests.agregar_profesor, name='xhr_agregar_profesor'),

                       url(r'^bug_reports/post/$', bug_report_post),
                       )
