from django.http import HttpResponseRedirect
from universidad.models import Materia, Profesor
from universidad.forms import MateriaForm, ProfesorForm
from reservas.models import Reservador
from utils.views.generics import create_with_json
import time

def agregar_materia(request):
    if not request.is_ajax:
        return HttpResponseRedirect('/reserva/')
    extra = { 'reservador': Reservador.objects.get(djuser=request.user) }
    return create_with_json(request, Materia, MateriaForm,
                            template_name = 'sitereserva/materias_form.html',
                            extra_context = extra, form_object_name = 'materia',
                            fields=('codigo','nombre'), return_success_json=True)

def agregar_profesor(request):
    if not request.is_ajax:
        return HttpResponseRedirect('/reserva/')
    extra = { 'reservador': Reservador.objects.get(djuser=request.user) }
    return create_with_json(request, Profesor, ProfesorForm,
                            template_name = 'sitereserva/profesor_form.html',
                            extra_context = extra, form_object_name = 'prof',
                            fields=('pk','nombre'), return_success_json=True)
