# -*- coding: utf-8 -*-

from django.http import HttpResponseRedirect, Http404
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.views.generic.simple import direct_to_template
from django.views.generic.list_detail import object_detail, object_list
from django.contrib.auth.decorators import permission_required

from sistemas.salas.models import Sala, Software
from sistemas.universidad.models import Materia
from sistemas.reservas.models import Reserva, SolicitudPermiso
from sistemas.utils.commons import SEMANAS

def inicio(request):
    return render_to_response('sitereserva/inicio.html', locals(), context_instance=RequestContext(request))

def horarios(request):
    if request.is_ajax:
        pass
    if request.POST:
        url_name = 'horario_actual'
        if request.POST['trimestre'] == 'siguiente':
            url_name = 'horario_siguiente'
        if request.POST['semana'] == 'todas':
            url_name = url_name + '_todas'
            return HttpResponseRedirect(reverse(url_name, args=[request.POST['sala']]))
        return HttpResponseRedirect(reverse(url_name, args=[request.POST['sala'], request.POST['semana']]))
    salas = Sala.objects.obtener_reservables().order_by('nombre')
    semanas = SEMANAS
    return render_to_response('sitereserva/horarios_index.html', locals(),
                              context_instance=RequestContext(request))

def materias_detail(request, codigo):
    materia = get_object_or_404(Materia, codigo=codigo)
    extra = { 'la_dictan': Reserva.objects.profesores_que_dictan(materia) }
    return object_detail(request, queryset=Materia.objects.all(), object_id=materia.pk,
                         template_object_name='materia',
                         template_name='sitereserva/materias_detail.html',
                         extra_context=extra)

# our lady peace
@permission_required('profesor.delete_profesor', login_url='/reserva/login/')
def solicitudes_list(request, status='en_espera'):
    if not request.user.is_staff:
        raise Http404
    qset = SolicitudPermiso.objects.get_by_status(status)#.order_by('submit_date')
    template_name = 'sitereserva/solicitud/list.html'
    extra = {'aceptadas': 'aceptadas',
             'rechazadas': 'rechazadas',
             'dudosas': 'dudosas',
             'todas': 'todas'}
    extra['status'] = status
    return object_list(request, queryset=qset, template_name=template_name, template_object_name='solicitud', extra_context=extra)

@permission_required('profesor.delete_profesor', login_url='/reserva/login/')
def solicitudes_detail(request, object_id):
    if not request.user.is_staff:
        raise Http404
    qset = SolicitudPermiso.objects.all()
    template_name = 'sitereserva/solicitud/ver.html'
    return object_detail(request, queryset=qset, object_id=object_id, template_name=template_name, template_object_name='solicitud')

def software_disponible(request, nombre):
    extra = { 'sala': Sala.objects.get(nombre__exact=nombre) }
    return direct_to_template(request, template='sitereserva/software_disponible.html',
                              extra_context=extra)
