from django.http import Http404, HttpResponseRedirect
from django.core.exceptions import ObjectDoesNotExist
from django.views.generic.simple import direct_to_template
from django.contrib.auth.decorators import permission_required

from sistemas.salas.models import Sala
from sistemas.universidad.models import Materia, Carrera, Profesor
from sistemas.reservas.models import Reserva, Reservador
from sistemas.universidad.forms import MateriaForm, ProfesorForm
from sistemas.reservas.forms import ReservaForm
from sistemas.utils.commons import SEMANAS, BLOQUEAR_SIGUIENTE
from sistemas.utils.views import obtener_trimestre

@permission_required('reservas.can_reserve', login_url='/reserva/login/')
def reserva_form(request, paso='1'):
    if paso == '1':
        extra = {
            'salas': Sala.objects.obtener_reservables(),
            'semanas': SEMANAS,
            'reservar_siguiente': BLOQUEAR_SIGUIENTE,
            }
        return direct_to_template(request, template='sitereserva/reserva_form/paso1.html',
                                  extra_context=extra)
    if paso == '2':
        if request.POST:
            # Valido los datos
            extra = request.POST.copy()
            semanas = SEMANAS
            if request.POST['semanas'] == 'pares':
                semanas = range(2,13,2)
            if request.POST['semanas'] == 'impares':
                semanas = range(3,13,2)
            if request.POST['semanas'] == 'otras':
                semanas = []
                for s in SEMANAS:
                    if request.POST.has_key('semana%s' % s):
                        semanas.append(s)
            extra['semanas'] = '-'.join('%s' % sem for sem in semanas)
            return direct_to_template(request, template='sitereserva/reserva_form/paso2.html',
                                      extra_context=extra)
    if paso == '3':
        if request.POST:
            # Si se esta tratando de agregar una nueva materia
            if request.POST.has_key('nueva_materia'):
                extra = request.POST.copy()
                data = {
                    'codigo': request.POST.get('codigo', False),
                    'nombre': request.POST.get('nombre', False),
                    'pertenece_carrera': request.POST.get('dpto', False)
                    }
                nueva_materia = MateriaForm(data)
                if not nueva_materia.is_valid():
                    print nueva_materia.errors
                    #for key, value in nueva_materia.errors:
                    #    extra[key] = value
                    extra['errors'] = nueva_materia.errors
                    extra['materia_desconocida'] = True
                    return direct_to_template(request, template='sitereserva/reserva_form/paso3.html',
                                              extra_context=extra)
                materia = nueva_materia.save()
                extra['message'] = 'Materia agregada correctamente'
                extra['paso'] = '4'
                extra['materia'] = materia.codigo
                return direct_to_template(request, template='sitereserva/reserva_form/confirmacion.html',
                                          extra_context=extra)

            # Si se quiere agregar una nueva materia:
            if request.POST.has_key('materia_desconocida'):
                extra = request.POST.copy()
                try:
                    extra['reservador'] = Reservador.objects.get(djuser__pk=request.user.pk)
                except ObjectDoesNotExist:
                    extra['reservador'] = False
                extra['departamentos'] = Carrera.objects.all()
                return direct_to_template(request, template='sitereserva/reserva_form/paso3.html',
                                          extra_context=extra)

            if request.POST.has_key('enviar_p3'):
                # Hubo exito en el primer intento, no se tuvo ke colocar una nueva materia
                extra = request.POST.copy()
                extra['message'] = 'Continuar al paso 4'
                extra['paso'] = '4'
                return direct_to_template(request, template='sitereserva/reserva_form/confirmacion.html',
                                          extra_context=extra)
            
            # tomo los datos q necesito de request.POST
            extra = { 'sala': request.POST['sala'],
                      'semanas': request.POST['semanas'],
                      'trimestre': request.POST['trimestre']
                    }
            # elimino los datos que saque
            # request.POST is inmutable... so duplico:
            posty = request.POST.copy()
            del posty['sala']
            del posty['semanas']
            del posty['trimestre']
            del posty['enviar']
            # Valido los datos .. FALTA EL unique_together-ness
            if not posty:
                pass # error, manejar hijaxed...
            # string de la forma: 'dia:hora-dia:hora-...' que representa las horas
            # seleccionadas
            horarios = '-'.join(['%s' % k for k in posty])
            extra['horarios'] = horarios
            extra['materias'] = Reservador.objects.obtener_materias_de_dpto(request.user.username)
            extra['materia_desconocida'] = False
            return direct_to_template(request, template='sitereserva/reserva_form/paso3.html',
                                      extra_context=extra)
    if paso == '4':
        # Valido datos del paso 3, si materia desconocida esta
        # marcada, me devuelvo al paso 3+1/2
        if request.POST:
            # Valido seccion
            prof_form = ProfesorForm()
            extra = request.POST.copy()
            print extra
            extra['prof_form'] = prof_form
            extra['reservador'] = Reservador.objects.get(djuser=request.user)
            extra['profesores'] = Reserva.objects.profesores_que_dictan(Materia.objects.get(codigo__exact=request.POST['materia']))
            return direct_to_template(request, template='sitereserva/reserva_form/paso4.html',
                                      extra_context=extra)
    raise Http404


def validar_reserva(request):
    if request.POST:
        extra = request.POST.copy()
        # Primero se valida al profesor
        if request.POST.has_key('nuevo_profesor'):
            data = {}
            for key in ['ci', 'nombre', 'telefono', 'email', 'oficina', 'pertenece_carrera']:
            # Buscar una mejor forma de hacer esto, listar los atributos de un modelo
            # Profesor.objects.all().values()[0] maybe..
                data[key] = request.POST.get(key, False)
                
            prof_form = ProfesorForm(data)
            if not prof_form.is_valid():
                extra['errors'] = prof_form.errors
                return direct_to_template(template='sitereserva/reserva_form/paso4.html',
                                          extra_context=extra)
            profesor = prof_form.save()
        else:
            if not request.POST.has_key('profesor'):
                extra['errors'] = {'all': 'No selecciono ningun profesor'}
                return direct_to_template(request,template='sitereserva/reserva_form/paso4.html',
                                          extra_context=extra)
            profesor = Profesor.objects.get(pk=request.POST['profesor'])
            
        # Los datos del profesor son validos
        # Ahora construyo el formulario de validacion de datos de la reserva
        materia = Materia.objects.get(codigo__exact=request.POST['materia'])
        reservador = Reservador.objects.get(djuser=request.user)
        sala = Sala.objects.get(nombre__exact=request.POST['sala'])
        r_dict = {}
        r_dict['seccion'] = request.POST.get('seccion', False)
        r_dict['trimestre'] = request.POST.get('trimestre', False)
        r_dict['trimestre'] = obtener_trimestre(r_dict['trimestre'])
        r_dict['materia'] = materia.pk
        r_dict['reservador'] = reservador.pk
        r_dict['sala'] = sala.pk
        r_dict['profesor'] = profesor.pk

        # Ahora tengo ke iterar sobre las semanas y las horas dadas
        # e ir guardando las reservas
        for semana in request.POST['semanas'].split('-'):
            for horario in request.POST['horarios'].split('-'):
                r_dict['semana'] = semana
                r_dict['dia'], r_dict['hora'] = horario.split(':')
                reserva_form = ReservaForm(r_dict)
                if reserva_form.is_valid():
                    reserva_form.save()
                else:
                    print 'Tragedia...'
                    print reserva_form.errors
                    print r_dict['seccion']
        return HttpResponseRedirect('../reserva_finalizada/')
    raise Http404
