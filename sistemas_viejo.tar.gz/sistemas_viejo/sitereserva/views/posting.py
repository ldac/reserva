# -*- coding: utf-8 -*-

from django.http import Http404, HttpResponseRedirect
from django.core.exceptions import ObjectDoesNotExist
from django.core.urlresolvers import reverse
from django.views.generic.simple import direct_to_template
from django.contrib.auth.decorators import permission_required
from django.views.decorators.http import require_POST
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.template.loader import render_to_string

from sistemas.salas.models import Sala, SolicitudSoftware
from sistemas.universidad.models import Materia, Departamento, Profesor
from sistemas.reservas.models import Reserva, Reservador, SolicitudPermiso
from sistemas.reservas.forms import SolicitudForm
from sistemas.salas.forms import SolicitudSoftwareForm
from sistemas.universidad.forms import MateriaForm, ProfesorForm
from sistemas.reservas.forms import ReservaForm
from sistemas.utils.commons import SEMANAS, BLOQUEAR_SIGUIENTE
from sistemas.utils.views.commons import obtener_trimestre, html_mail_admins
from sistemas.utils.views.generics import create_with_json

@permission_required('reservas.can_reserve', login_url='/reserva/login/')
def reserva_form(request, paso='1'):
    if paso == '1':
        extra = {
            'salas': Sala.objects.obtener_reservables(),
            'bloquear_siguiente': BLOQUEAR_SIGUIENTE,
            }
        if request.POST:
            # valido los datos, genero el diccionario de respuesta,
            semanas = []
            if request.POST['semanas'] == 'otras':
                if not request.POST.has_key('mostrar_custom_semanas'): # me estan solicitando mostrarlas
                    extra['mostrar_custom_semanas'] = True
                    extra['semanas'] = SEMANAS
                    extra['sala'] = request.POST.get('sala', 'A')
                    #if request.is_ajax():
                    #    return json
                    return direct_to_template(request, template='sitereserva/reserva_form/paso1.html',
                                       extra_context=extra)
                for s in SEMANAS:
                    if request.POST.has_key('semana%s' % s):
                        semanas.append(s)
            if request.POST['semanas'] == 'pares':
                semanas = range(2,13,2)
            if request.POST['semanas'] == 'impares':
                semanas = range(3,13,2)
            if request.POST['semanas'] == 'todas':
                semanas = range(2,13)
            errores = {}
            if not semanas:
                errores['semanas'] = 'Por favor selecciona semanas para reservar las salas'
            if not request.POST.has_key('sala'):
                errores['sala'] = 'Selecciona la sala que quieras reservar'
            if not request.POST.has_key('trimestre'):
                errores['trimestre'] = 'Selecciona el trimestre'
            if errores:
                extra['errors'] = errores
                #if request.is_ajax():
                #    return json
                return direct_to_template(request, template='sitereserva/reserva_form/paso1.html',
                                          extra_context=extra)
            
            # Si no hay errores entonces creo el diccionario en sessions y
            # redirecciono al paso 2
            request.session['datos_reserva'] = {}
            request.session['datos_reserva'] = {
                'trimestre': request.POST['trimestre'],
                'sala': request.POST['sala'],
                'semanas': '-'.join('%s' % sem for sem in semanas),
                # datos de control del formulario:
                'pasos_recorridos': ['1', '2']
                }
            return HttpResponseRedirect(reverse('reservar_con_paso', args=['2']))
        
        return direct_to_template(request, template='sitereserva/reserva_form/paso1.html',
                                  extra_context=extra)
    if paso == '2':
        # Chequeo si vengo del paso anterior
        if 'datos_reserva' not in request.session or paso not in request.session['datos_reserva']['pasos_recorridos']:
            return HttpResponseRedirect(reverse('reservar'))

        extra = request.session['datos_reserva'].copy()
        if request.POST:
            errores = {}
            # request.POST es inmutable... so duplico:
            posty = request.POST.copy()
            del posty['enviar']
            # Veo si no hay horarios
            if not posty:
                errores['horarios'] = 'Selecciona horas para reservar la sala %s' % extra['sala']
                extra['errors'] = errores
                return direct_to_template(request, template='sitereserva/reserva_form/paso2.html',
                                          extra_context=extra)

            # Si no hay errores entonces modifico el datos_reserva y
            # redirecciono al paso 3
            request.session['datos_reserva']['horarios'] = '-'.join('%s' % key for key in posty)
            # modifico los datos de control
            if not '3' in request.session['datos_reserva']['pasos_recorridos']:
                request.session['datos_reserva']['pasos_recorridos'].append('3')
            return HttpResponseRedirect(reverse('reservar_con_paso', args=['3']))
        
        return direct_to_template(request, template='sitereserva/reserva_form/paso2.html',
                                  extra_context=extra)
    if paso == '3':
        # Chequeo si vengo del paso anterior
        if 'datos_reserva' not in request.session or paso not in request.session['datos_reserva']['pasos_recorridos']:
            return HttpResponseRedirect(reverse('reservar'))

        extra = {
            'reservador': Reservador.objects.get(djuser=request.user),
            'materias': Reservador.objects.obtener_materias_de_dpto(request.user.username),
            'materia_desconocida': False
            }
        if request.POST:
            errores = {}
            # veo si hay errores:
            if not request.POST.has_key('seccion'):
                errores['seccion'] = u'Por favor introduce una sección'
            seccion = str(request.POST['seccion'])
            if not seccion.isdigit():
                errores['seccion'] = u'Por favor introduce una sección válida (numero natural)'
            if request.POST.has_key('materia_desconocida'):
                if not request.POST.has_key('nueva_materia'):
                    # Primera vez que se le da al boton de materia_desconocida
                    extra['form_materia'] = MateriaForm()
                    extra['materia_desconocida'] = True
                    extra['seccion'] = request.POST.get('seccion',False)
                    return direct_to_template(request, template='sitereserva/reserva_form/paso3.html',
                                              extra_context=extra)
                else:
                    # ya mostre una vez el form de nueva materia, ahora valido datos
                    datos_materia = {
                        'dpto': request.POST.get('dpto', False),
                        'codigo': request.POST.get('codigo', False),
                        'nombre': request.POST.get('nombre', False)
                        }
                    form_materia = MateriaForm(datos_materia)
                    if not form_materia.is_valid():
                        errores['nueva_materia'] = form_materia.errors
            else:
                # Si no esta marcado el materia_desconocida entonces tiene que haber una
                # materia seleccionada
                cod_materia = request.POST.get('materia')
                if not cod_materia:
                    errores['materia'] = 'Por favor seleccione una materia'
            # si hay errores
            if errores:
                extra['errors'] = errores
                #if request.is_ajax():
                #    return json
                if request.POST.has_key('nueva_materia'):
                    extra['form_materia'] = MateriaForm()
                    extra['materia_desconocida'] = True
                    extra['seccion'] = request.POST.get('seccion', False)
                return direct_to_template(request, template='sitereserva/reserva_form/paso3.html',
                                          extra_context=extra)

            # si no hay errores, pero se coloco una nueva materia, hay que guardarla
            if request.POST.has_key('materia_desconocida'):
                materia = form_materia.save()
            else:
                materia = Materia.objects.get(codigo__exact=cod_materia)
            # guardo los datos en datos_reserva
            request.session['datos_reserva']['seccion'] = seccion
            request.session['datos_reserva']['materia'] = materia
            # modifico los datos de control
            if not '4' in request.session['datos_reserva']['pasos_recorridos']:
                request.session['datos_reserva']['pasos_recorridos'].append('4')
            return HttpResponseRedirect(reverse('reservar_con_paso', args=['4']))
            
        return direct_to_template(request, template='sitereserva/reserva_form/paso3.html',
                                  extra_context=extra)
    if paso == '4':
        ## IMPORTANTE: restriccion explicita - si el reservador no es
        ## super-reservador, se tiene que chequear que la
        ## materia__dpto sea igual a reservador__dpto al ingresar
        ## la nueva reserva
        if 'datos_reserva' not in request.session or paso not in request.session['datos_reserva']['pasos_recorridos']:
            return HttpResponseRedirect(reverse('reservar'))
        errores = {}
        extra = {
            'profesores': Profesor.objects.all().order_by('nombre'),#Reserva.objects.profesores_que_dictan(request.session['datos_reserva']['materia']),
            'prof_form': ProfesorForm(),
            'reservador': Reservador.objects.get(djuser=request.user)
            }
        if not extra['reservador'].super_reservador:
            extra['profesores'] = Profesor.objects.filter(dpto__pk=extra['reservador'].dpto.pk)
        if request.POST:
            if request.POST.has_key('no_profesor'):
                profesor = None
            elif request.POST.has_key('nuevo_profesor'):
                prof_form = ProfesorForm(request.POST)
                if prof_form.is_valid():
                    profesor = prof_form.save()
                else:
                    extra['nuevo_profesor'] = True
                    errores['nuevo_profesor'] = prof_form.errors
            else:
                prof_pk = request.POST.get('profesor', False)
                if not prof_pk:
                    errores['profesor'] = 'Por favor seleccione un profesor para dictar la materia'
                else:
                    profesor = Profesor.objects.get(pk=prof_pk)
            # si hay errores, los mando
            if errores:
                extra['errors'] = errores
                return direct_to_template(request, template='sitereserva/reserva_form/paso4.html',
                                          extra_context=extra)
            # si no hay errores, guardo todo y continuo
            request.session['datos_reserva']['profesor'] = profesor
            if not 'validar' in request.session['datos_reserva']['pasos_recorridos']:
                request.session['datos_reserva']['pasos_recorridos'].append('validar')
            return HttpResponseRedirect(reverse('reservar_validacion'))
        return direct_to_template(request, template='sitereserva/reserva_form/paso4.html',
                                  extra_context=extra)
    return HttpResponseRedirect(reverse('reservar'))


@permission_required('reservas.can_reserve', login_url='/reserva/login/')
def validar_reserva(request):
    if 'datos_reserva' not in request.session or 'validar' not in request.session['datos_reserva']['pasos_recorridos']:
        return HttpResponseRedirect(reverse('inicio'))
    r_dict = request.session['datos_reserva'].copy()
    r_dict['sala'] = Sala.objects.get(nombre__exact=r_dict['sala'])
    r_dict['reservador'] = Reservador.objects.get(djuser=request.user)
    r_dict['trimestre'] = obtener_trimestre(r_dict['trimestre'])
    r_dict['semanas'] = r_dict['semanas'].split('-')
    r_dict['horarios'] = r_dict['horarios'].split('-')
    # Arreglar como se ve el horario
    def to_string_day(day):
        sdays = [u'Lunes', u'Martes', u'Miércoles', u'Jueves', u'Viernes']
        return sdays[int(day) - 1]
    diashoras = [diahora.split(':') for diahora in r_dict['horarios']]
    r_dict['horarios'] = {}
    for dia, hora in diashoras:
        r_dict['horarios'].setdefault(to_string_day(dia), []).append(int(hora))
    for val in r_dict['horarios'].values():
        val.sort() # ordeno las horas
    return direct_to_template(request, template='sitereserva/reserva_form/confirmar_reserva.html',
                              extra_context=r_dict)

@require_POST
def reserva_finalizada(request):
    if 'datos_reserva' not in request.session or 'validar' not in request.session['datos_reserva']['pasos_recorridos']:
        return HttpResponseRedirect(reverse('inicio'))

    r_dict = request.session['datos_reserva'].copy()
    r_dict['sala'] = Sala.objects.get(nombre__exact=r_dict['sala'])
    r_dict['reservador'] = Reservador.objects.get(djuser=request.user)
    r_dict['trimestre'] = obtener_trimestre(r_dict['trimestre'])
    r_dict['semanas'] = r_dict['semanas'].split('-')
    r_dict['horarios'] = r_dict['horarios'].split('-')
    msg_dict = r_dict.copy()
    for key in ['materia', 'reservador', 'sala', 'profesor']:
        if r_dict[key] is not None: r_dict[key] = r_dict[key].pk
        # Ahora tengo ke iterar sobre las semanas y las horas dadas
        # e ir guardando las reservas
    for semana in r_dict['semanas']:
        r_dict['semana'] = semana
        for horario in r_dict['horarios']:
            r_dict['dia'], r_dict['hora'] = horario.split(':')
            print r_dict['dia'], r_dict['hora']
            reserva_form = ReservaForm(r_dict)
            if reserva_form.is_valid():
                from MySQLdb import IntegrityError
                from pprint import pprint
                try:
                    r = reserva_form.save()
                except IntegrityError:
                    msg  = u'Error realizando la reservación. El horario elegido ha '
                    msg += u'sido tomado por otra persona.'
                    extra = { 'message': msg }
                    return direct_to_template(request,
                                              template='sitereserva/reserva_form/confirmacion.html',
                                              extra_context=extra)
            else:
                print 'Tragedia...'
                print reserva_form.errors
                raise Http404
    message = render_to_string('sitereserva/emails/reserva_realizada.txt',
                               {'reserva': msg_dict})
    html_mail_admins('Reserva Realizada', message, fail_silently=True)
    # Borro todo los datos de la reserva de las sessiones
    del request.session['datos_reserva']
    return direct_to_template(request, template='sitereserva/reserva_form/confirmacion.html',
                              extra_context={ 'message': 'Reserva realizada correctamente.' })


def hacer_solicitud_permiso(request):
    from django.core.exceptions import ImproperlyConfigured
    try:
        return create_with_json(request, model=SolicitudPermiso, newform_class=SolicitudForm,
                                form_object_name='solicitud',
                                template_name='sitereserva/solicitud/form.html')
    except ImproperlyConfigured:
        sol = SolicitudPermiso.objects.get(login__exact=request.POST['login'])
        #Mando el email
        message = render_to_string('sitereserva/emails/nueva_solicitud.txt',
                                  {'solicitud': sol})
        html_mail_admins('Nueva solicitud de registro', message)
        return HttpResponseRedirect('/reserva/solicitud/confirmar/')

@require_POST
@permission_required('profesor.delete_profesor', login_url='/reserva/login/')
def solicitudes_procesar(request):
    for name in request.POST:
        if not name == 'enviar':
            sol = SolicitudPermiso.objects.get(pk=int(name))
            # Si es aceptar, se genera el usuario y se manda el email
            # si es dudoso se manda el email para que la persona venga
            if request.POST[name] == '1':
                passwd = User.objects.make_random_password()
                u = User.objects.create_user(sol.login, sol.email, passwd)
                u.first_name = sol.nombre
                u.last_name = sol.apellido
                from django.contrib.auth.models import Group
                u.groups.add(Group.objects.get(name__exact='Reservadores'))
                u.save()
                reservador = Reservador(djuser=u, ci=sol.ci, dpto=sol.dpto, oficina=sol.oficina,
                                        telefono=sol.telefono, super_reservador=False)
                reservador.save()
                # mando el email de confirmacion
                msg = render_to_string('sitereserva/emails/solicitud_aprobada.txt',
                                       {'passwd': passwd})
                send_mail(subject = '[AC/Reserva] Solicitud de registro aprobada',
                          message = msg,
                          from_email = 'reserva@ac.labf.usb.ve',
                          recipient_list = [sol.email])
            elif request.POST[name] == '0':
                # busco si ya el usuario existia y lo baneo, sino
                # simplemente le cambio el status
                reservador = Reservador.objects.filter(djuser__login__exact=sol.login)
                if reservador:
                    reservador.djuser.is_active = False
            else:
                # estamos diciendo ke la solicitud es dudosa,
                # simplemente se le manda el email de confirmacion a
                # la persona
                msg = render_to_string('sitereserva/emails/solicitud_dudosa.txt', {})
                send_mail(subject = '[AC/Reserva] Solicitud de registro en espera',
                          message = msg,
                          from_email = 'reserva@ac.labf.usb.ve',
                          recipient_list = [sol.email])
            # Por ultimo cambio el status a la solicitud y la guardo
            sol.status = request.POST[name]
            sol.save()
    return HttpResponseRedirect(reverse('solicitudes_index'))

@permission_required('reservas.can_reserve', login_url='/reserva/login/')
def solicitar_software(request):
    data = None
    if request.POST:
        data = request.POST.copy()
        data['reservador'] = request.user.pk
        data['status'] = 'P'
        # Forma pirata de hacer el field ip_address auto-populated,
        # hay que mejorarlo para que sea independiente de esta vista
        data['ip_address'] = request.META['REMOTE_ADDR']
        
    # Se pasan las materias relativas al departamento del usuario
    reservador = Reservador.objects.get(djuser=request.user)
    # Todas si es super_reservador
    if reservador.super_reservador:
        materias = Materia.objects.all()
    else:
        materias = Materia.objects.filter(dpto=reservador.dpto)  

    return create_with_json(request, model=SolicitudSoftware, newform_class=SolicitudSoftwareForm,
                            template_name='sitereserva/software_solicitar.html',
                            post_save_redirect=reverse('solicitar_software_finalizado'), post_replace_dict=data,
                            login_required=True,extra_context={'materias':materias})


def desreservar(request, paso='1'):
    if paso == '1':
        extra = {
            'salas': Sala.objects.obtener_reservables()
            }
        if request.POST:
            errores = {}
            if not request.POST['trimestre']:
                errores = { 'trimestre': 'Por favor seleccione un trimestre', }
            if not request.POST['sala']:
                errores = { 'sala': 'Por favor seleccione una sala', }

            if not errores:
                request.session['eliminar_reserva'] = {
                    'trimestre': request.POST['trimestre'],
                    'sala': request.POST['sala'],
                    'pasos_recorridos': ['1', '2']
                    }
                return HttpResponseRedirect(reverse('eliminar_reserva_con_paso', args=['2']))

            extra['errors'] = errores
            return direct_to_template(request, template='sitereserva/desreservar/paso1.html',
                                      extra_context=extra)
        
        request.session['eliminar_reserva'] = {}
        return direct_to_template(request, 'sitereserva/desreservar/paso1.html',
                                  extra_context=extra)

    if paso == '2':
        if 'eliminar_reserva' not in request.session or paso not in request.session['eliminar_reserva']['pasos_recorridos']:
            return HttpResponseRedirect(reverse('eliminar_reserva'))

        reservador = Reservador.objects.get(djuser=request.user)
        # Busco las materias que se dictan en ese trimestre y esa sala
        trimestre = obtener_trimestre(request.session['eliminar_reserva']['trimestre'])
        sala = Sala.objects.get(nombre__exact=request.session['eliminar_reserva']['sala'])
        reservas = Reserva.objects.filter(trimestre = trimestre, sala = sala)
        if not reservador.super_reservador:
            materias = [reserva.materia
                        for reserva in reservas
                        if reserva.materia.dpto == reservador.dpto]
        else:
            materias = [reserva.materia for reserva in reservas]
            
        extra = {
            'reservador': reservador,
            'materias': list(set(materias)),
            }

        if request.POST:
            cod_materia = request.POST.get('materia', False)
            if not cod_materia:
                errores = { 'materia': 'Debe seleccionar una materia.' }
                extra['errors'] = errores
                return direct_to_template(request, 'sitereserva/desreservar/paso2.html',
                                          extra_context=extra)
            request.session['eliminar_reserva']['materia'] = Materia.objects.get(codigo__exact=cod_materia)
            if not '3' in request.session['eliminar_reserva']['pasos_recorridos']:
                request.session['eliminar_reserva']['pasos_recorridos'].append('3')
            return HttpResponseRedirect(reverse('eliminar_reserva_con_paso', args=['3']))

        return direct_to_template(request, 'sitereserva/desreservar/paso2.html',
                                  extra_context=extra)

    if paso == '3':
        if 'eliminar_reserva' not in request.session \
        or 'pasos_recorridos' not in request.session['eliminar_reserva'] \
        or paso not in request.session['eliminar_reserva']['pasos_recorridos']:
            return HttpResponseRedirect(reverse('eliminar_reserva'))
        extra = request.session['eliminar_reserva'].copy()

        if request.POST:
            errores = {}
            posty = request.POST.copy()
            del posty['enviar']
            # Veo si no hay horarios
            if not posty:
                errores['horarios'] = 'Selecciona horas para eliminar reservas'
                extra['errors'] = errores
                return direct_to_template(request, template='sitereserva/desreservar/paso3.html',
                                          extra_context=extra)

            # Si no hay errores entonces modifico el datos_reserva y
            # redirecciono al paso 3
            request.session['eliminar_reserva']['horarios'] = [hora for hora in posty]
            # modifico los datos de control
            if not '4' in request.session['eliminar_reserva']['pasos_recorridos']:
                request.session['eliminar_reserva']['pasos_recorridos'].append('4')
            return HttpResponseRedirect(reverse('eliminar_reserva_con_paso', args=['4']))
        
        return direct_to_template(request, 'sitereserva/desreservar/paso3.html',
                                  extra_context=extra)

    if paso == '4':
        if 'eliminar_reserva' not in request.session or paso not in request.session['eliminar_reserva']['pasos_recorridos']:
            return HttpResponseRedirect(reverse('eliminar_reserva'))

        semanas = []
        sala = Sala.objects.get(nombre__exact=request.session['eliminar_reserva']['sala'])
        trimestre = obtener_trimestre(request.session['eliminar_reserva']['trimestre'])

        for diahora in request.session['eliminar_reserva']['horarios']:
            dia, hora = diahora.split(':')
            reservas = Reserva.objects.filter(sala = sala,
                                              trimestre = trimestre,
                                              materia = request.session['eliminar_reserva']['materia'],
                                              hora = hora, dia = dia)
            semanas = semanas + filter(lambda x: x not in semanas, [reserva.semana for reserva in reservas])
        extra = { 'semanas': semanas }
        if request.POST:
            errores = {}
            posty = request.POST.copy()
            del posty['enviar']

            if not posty:
                extra['errors']['semanas'] = 'Selecciona al menos una semana para eliminar reservas'
                return direct_to_template(request, template='sitereserva/desreservar/paso4.html',
                                          extra_context=extra)
            if 'todas' in posty:
                request.session['eliminar_reserva']['semanas'] = SEMANAS
            else:
                request.session['eliminar_reserva']['semanas'] = [semana for semana in posty]
            # modifico los datos de control
            if not 'validar' in request.session['eliminar_reserva']['pasos_recorridos']:
                request.session['eliminar_reserva']['pasos_recorridos'].append('validar')
            return HttpResponseRedirect(reverse('validacion_eliminar_reserva'))

        return direct_to_template(request, 'sitereserva/desreservar/paso4.html',
                                  extra_context=extra)
            
    # no paso, me voy a la pagina principal
    return HttpResponseRedirect(reverse('inicio'))


@permission_required('reservas.can_reserve', login_url='/reserva/login/')
def desreservar_validacion(request):
    if 'eliminar_reserva' not in request.session or 'validar' not in request.session['eliminar_reserva']['pasos_recorridos']:
        return HttpResponseRedirect(reverse('eliminar_reserva'))

    request.session['eliminar_reserva']['sala'] = Sala.objects.get(nombre__exact = request.session['eliminar_reserva']['sala'])
    request.session['eliminar_reserva']['trimestre'] = obtener_trimestre(request.session['eliminar_reserva']['trimestre'])
    extra = request.session['eliminar_reserva'].copy()
    return direct_to_template(request, 'sitereserva/desreservar/validacion.html',
                                  extra_context=extra)


@require_POST
def desreservar_finalizado(request):
    er = request.session['eliminar_reserva'].copy()
    for semana in er['semanas']:
        for diahora in er['horarios']:
            dia, hora = diahora.split(':')
            try:
                reserva = Reserva.objects.get(sala = er['sala'],
                                              trimestre = er['trimestre'],
                                              materia = er['materia'],
                                              hora = hora, dia = dia, semana = semana)
                #reserva.habilitada = False
                #reserva.save()
                reserva.delete()
            except:
                continue
            
    del request.session['eliminar_reserva']
    return direct_to_template(request, 'sitereserva/desreservar/confirmacion.html')
