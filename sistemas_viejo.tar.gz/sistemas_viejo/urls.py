from django.conf.urls.defaults import *
from django.contrib import admin
from django.conf import settings
from views import *

admin.autodiscover()

urlpatterns = patterns('',
                       (r'^admin/(.*)', admin.site.root),
                       (r'^sitemedia/(.*)$', 'django.views.static.serve', {'document_root': settings.MEDIA_ROOT}, 'media_url'),
                       (r'^sistemas/$', inicio),
                       (r'^login/', login_and_return),
                       (r'^logout/$', logout_and_return),
                       
                       (r'^reserva/', include('sitereserva.urls')),

)
