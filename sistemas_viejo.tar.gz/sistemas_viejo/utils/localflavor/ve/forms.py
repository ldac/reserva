"""
Venezuelan specific form helpers.
"""

from django.forms import ValidationError
from django.forms.fields import Field, EMPTY_VALUES
from django.utils.translation import ugettext_lazy as _
import re

phone_digits_re = re.compile('^(\d{4}(-| )?)?\d{7}$')

class VEPhoneNumberField(Field):
    """
    Accept the usual venezuelan phone codification: XXXX-XXXXXXX.
    """
    default_error_messages = {
        'invalid': _(u'Enter a valid phone number in the format XXXX-XXXXXXX'),
        }

    def clean(self, value):
        value = super(VEPhoneNumberField, self).clean(value)
        if value in EMPTY_VALUES:
            return u''

        m = phone_digits_re.search(value)
        if m:
            return re.sub('(-| )', '', value)
        raise ValidationError(self.error_messages['invalid'])
