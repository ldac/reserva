from django.forms import ValidationError

def formfield_factory(model_field, **kwargs):
    form_field = model_field.formfield(**kwargs)
    if form_field:
        form_field.model_field = model_field
    return form_field


def _join(l):
    l = list(l)
    return '%s and %s' % (', '.join(l[:-1]), l[-1])


def validate_unique_constraint(form, Model, model, field_names):
    '''Check a single 'unique' or 'unique_together' constraint'''
    filter = {}
    # search for other objects with the same data for the unique fields
    for field_name in field_names:
        if field_name not in form.cleaned_data:
            # No cleaned data for the field means either that the field is
            # nullable and was left empty or that the field itself did not
            # validate.
            return
        filter[field_name] = form.cleaned_data[field_name]
    query_set = Model.objects.filter(**filter)
    # exclude model instance
    if model is not None:
        query_set = query_set.exclude(id=model.id)
    # raise ValidationError if query gives a result
    if query_set.count() > 0:
        if len(field_names) > 1:
            raise ValidationError('Los campos %s deben ser unicos juntos entre si.' \
                % _join('"%s"' % Model._meta.get_field(field_name).verbose_name for field_name in field_names))
        else:
            raise ValidationError('El campo "%s" debe ser unico.' \
                % Model._meta.get_field(field_names[0]).verbose_name)


def validate_unique_constraints(form, Model, model=None):
    '''Check 'unique' and 'unique_together' constraints defined in the Model and Fields.'''
    # check 'unique' constraints defined in the fields
    for field_name in form.fields:
        model_field = Model._meta.get_field(field_name)
        if model_field.unique:
            validate_unique_constraint(form, Model, model, [field_name])
    # check 'unique_together' constraints defined in the model
    unique_together = Model._meta.unique_together
    for field_names in unique_together:
        validate_unique_constraint(form, Model, model, field_names)


def enhance_form(Form, Model, model=None):
    '''Wrap the Form.clean method and add checks for unique constraints.'''
    wrapped_clean = Form.clean
    def clean(form):
        form.cleaned_data = wrapped_clean(form)
        validate_unique_constraints(form, Model, model)
        return form.cleaned_data
    Form.clean = clean


# def form_for_model(Model, **kwargs):
#     from django.newforms.models import form_for_model
#     Form = form_for_model(Model, formfield_callback=formfield_factory, **kwargs)
#     enhance_form(Form, Model)
#     return Form


# def form_for_instance(model, **kwargs):
#     from django.newforms.models import form_for_instance
#     Form = form_for_instance(model, formfield_callback=formfield_factory, **kwargs)
#     enhance_form(Form, type(model), model)
#     return Form
