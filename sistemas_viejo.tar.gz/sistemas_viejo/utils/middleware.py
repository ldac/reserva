
class AjaxCheckMiddleware(object):
	def process_request(self, request):
		is_ajax = request.META.get('HTTP_X_REQUESTED_WITH', None) == 'XMLHttpRequest'
		setattr(request, 'is_ajax', is_ajax)
		return None
