from django.template import Library, Node, TemplateSyntaxError

register = Library()

class DoRangeNode(Node):
    def __init__(self, first, last, varname):
        self.first, self.last, self.varname = first, last, varname

    def render(self, context):
        context[self.varname] = range(self.first, self.last)
        return ''

class DoRange:
    """
    Modo de uso:
    {% for_range between first last as counter %}
    """
    def __call__(self, parser, token):
        tokens = token.split_contents()
        if len(tokens) != 6:
            raise TemplateSyntaxError, "%r tag requires exactly 5 arguments" % tokens[0]
        if tokens[1] != 'between':
            raise TemplateSyntaxError, "First argument in %r tag must be 'between'" % tokens[0]
        if not (tokens[2].isdigit() and tokens[3].isdigit()):
            raise TemplateSyntaxError, "Second and Thirth arguments in %r tag must be digits" % tokens[0]
        first, last = int(tokens[2]), int(tokens[3])
        if first > last:
            raise TemplateSyntaxError, "Second argument in %r tag must be lower or equal than the thirth one" % tokens[0]
        if tokens[4] != 'as':
            raise TemplateSyntaxError, "Fourth argument in %r tag must be 'as'" % tokens[0]

        return DoRangeNode(first, last, tokens[5])
    
register.tag('do_range', DoRange())
