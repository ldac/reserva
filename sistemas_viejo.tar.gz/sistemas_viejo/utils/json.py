from django.utils.simplejson import JSONEncoder
from django.utils.functional import Promise
from django.utils.translation import force_unicode

# Lazy Serializer para los diccionarios que tengan lazy strings como
# forms.errors...
class JSONLazyEncoder(JSONEncoder):
    def default(self, o):
        if isinstance(o, Promise):
            return force_unicode(o)
        else:
            return super(LazyEncoder, self).default(o)
