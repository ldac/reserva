import datetime
from django.utils.simplejson import JSONEncoder
from django.utils.functional import Promise
#from django.utils.translation import force_unicode
from django.core.mail import SMTPConnection, EmailMessage
from django.conf import settings

TRIMESTRES = (
    ([9,1], [12,31], 'sep-dic-'),   #
    ([1,1], [4,15], 'ene-mar-'),    # [mes, dia]
    ([4,16], [8,30], 'abr-jul-'),
    )

def obtener_trimestre(t='actual'):
    hoy = datetime.date.today()
    for i in range(0,len(TRIMESTRES)):
        meses = TRIMESTRES[i]
        inicio = datetime.date(hoy.year, meses[0][0], meses[0][1])
        final  = datetime.date(hoy.year, meses[1][0], meses[1][1])

        if inicio <= hoy <= final:
            trimestre = i

    if t != 'actual':
        if TRIMESTRES[trimestre][2] == 'sep-dic-':
            return '%s%s' % (TRIMESTRES[(trimestre + 1) % 3][2], hoy.year+1)
        else:
            return '%s%s' % (TRIMESTRES[(trimestre + 1) % 3][2], hoy.year)
    else:
        return '%s%s' % (TRIMESTRES[trimestre][2], hoy.year)
        
def send_html_mail(subject, message, from_email, recipient_list,
                   fail_silently=False, auth_user=None, auth_password=None):
    connection = SMTPConnection(username=auth_user, password=auth_password,
                                fail_silently=fail_silently)
    mail = EmailMessage(subject, message, from_email, recipient_list,
                        connection=connection)
    mail.content_subtype = "html"
    return mail.send(fail_silently=fail_silently)

def html_mail_admins(subject, message, fail_silently=False):
    """Sends a message to the admins, as defined by the ADMINS setting."""
    mail = EmailMessage(settings.EMAIL_SUBJECT_PREFIX + subject,
                        message, settings.SERVER_EMAIL,
                        [a[1] for a in settings.ADMINS])
    mail.content_subtype = "html"
    mail.send(fail_silently=fail_silently)
