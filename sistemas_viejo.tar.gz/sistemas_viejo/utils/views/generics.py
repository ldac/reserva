from django.template import RequestContext, loader
from django.contrib.auth.views import redirect_to_login
from django.http import HttpResponse, HttpResponseRedirect
from django.utils import simplejson
from utils.json import JSONLazyEncoder
from django.db.models import FileField
from django.core.exceptions import ImproperlyConfigured
from django.utils.translation import ugettext

def create_with_json(request, model, newform_class, fields=None, template_name=None,
                     template_loader=loader, extra_context=None, post_save_redirect=None,
                     post_replace_dict=None, form_object_name=None, login_required=False,
                     return_success_json=False, context_processors=None):
    """
    Adaptacion de django.views.generic.create_update.* para que
    utilicen newforms y puedan manejar respuestas en json si la
    peticion esta dada con xhr

    Default Template: ``<app_label>/<model_name>_form.html``
    Otros parametros:
        form_object_name: nombre del objeto al cual se le esta
        haciendo el form. Si form_object_name='foo', en el
        contexto estara foo_form que sera la variable que
        representara el form en el template.

        form_object_name default: ``<model_name>``
    Context:
        <form_object_name or model_name>_form
            the newform object that handles the model form template
    """
    if login_required and not request.user.is_authenticated():
        return redirect_to_login(request.path)
    
    if template_name is None:
        template_name = '%s/%s_form.html' % (model._meta.app_label, model._meta.object_name.lower())
    if extra_context is None:
        extra_context = {}
    if form_object_name is None:
        form_object_name = model._meta.object_name.lower()

    if request.POST:
        # Enviaron informacion del formulario, si valida creamos el objeto
        data = post_replace_dict or request.POST.copy()

        #if model._meta.has_field_type(FileField):
        #    data.update(request.FILES)

        form = newform_class(data)
        response_dict = {}

        if form.is_valid():
            new_object = form.save()

            if request.user.is_authenticated():
                request.user.message_set.create(message=ugettext("The %(verbose_name)s was created successfully.") % {'verbose_name': model._meta.verbose_name})

            # si se quiere retornar json, se devuelve un diccionario que
            # solo posea un certificado de que hubo un success. La forma
            # de manejar dicho success sera parte del js layer.
            if request.is_ajax and return_success_json:
                response_dict = { 'success': True }
                if fields is not None:
                    for field in fields: 
                        if field == 'pk':
                            response_dict[field] = new_object._get_pk_val()
                        else:
                            response_dict[field] = new_object.__dict__.get(field)
                return HttpResponse(simplejson.dumps(response_dict, cls=JSONLazyEncoder), mimetype='application/javascript')

            # as in create_update.create_object view, redirige primero
            # revisando post_save_redirect, luego obj.get_absolute_url
            # y si no logra nada, falla
            if post_save_redirect:
                return HttpResponseRedirect(post_save_redirect % new_object.__dict__)
            elif hasattr(new_object, 'get_absolute_url'):
                return HttpResponseRedirect(new_object.get_absolute_url())
            else:
                raise ImproperlyConfigured('No URL to redirect to from generic create view.')
        else:
            response_dict = form.errors
            response_dict.update({'success': False})
            
        # Doy la respuesta final
        if request.is_ajax:
            return HttpResponse(simplejson.dumps(response_dict, cls=JSONLazyEncoder), mimetype='application/javascript')

    else:
        # No post, simplemente creamos el formulario a renderizar
        form = newform_class()
        
    template = template_loader.get_template(template_name)
    for key, value in extra_context.items():
        if callable(value):
            extra_context[key] = value()
        else:
            extra_context[key] = value
    extra_context['%s_form' % form_object_name] = form
    context = RequestContext(request, extra_context, context_processors)
    
    return HttpResponse(template.render(context))
