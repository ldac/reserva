from django.contrib import admin
from universidad.models import Departamento, Materia, Profesor

class DepartamentoAdmin(admin.ModelAdmin):
    pass

class MateriaAdmin(admin.ModelAdmin):
    pass

class ProfesorAdmin(admin.ModelAdmin):
    pass

admin.site.register(Departamento, DepartamentoAdmin)
admin.site.register(Materia, MateriaAdmin)
admin.site.register(Profesor, ProfesorAdmin)
