# -*- coding: utf-8 -*-

from django.forms import ModelForm,ValidationError
from sistemas.utils.localflavor.ve import forms as ve_forms
from sistemas.universidad.models import Materia, Profesor
import re

class MateriaForm(ModelForm):
    #El nombre de la materia debe matchear la expresion regular
    #LLDDDD donde L: letra y D: digito
    def clean_codigo(self):         
        codigo=re.compile('[A-Za-z]{2}\d{4}$')
        matching=codigo.match(self.cleaned_data['codigo'])
        if not matching:
            raise ValidationError(u'Este campo es obligatorio. Ingrese el código en el formato LLDDDD, L: letra y D: dígito.')
        else:
            return self.cleaned_data['codigo']

    class Meta:
        model = Materia

class ProfesorForm(ModelForm):
    telefono = ve_forms.VEPhoneNumberField()
    class Meta:
        model = Profesor
