from django.db import models
from utils.localflavor.ve import forms as ve_forms

class Departamento(models.Model):
    codigo = models.CharField(max_length=5, blank=True)
    nombre = models.CharField(max_length=50, unique=True)
    direccion = models.CharField(max_length=100, blank=True)

    def __unicode__(self):
        cod = ''
        if self.codigo:
            cod = '(%s) ' % self.codigo
        return cod + '%s' % self.nombre

    class Admin:
        pass

class Materia(models.Model):
    codigo = models.CharField(max_length=8, unique=True)
    nombre = models.CharField(max_length=50)
    dpto = models.ForeignKey(Departamento)

    def __unicode__(self):
        return '(%s) %s' % (self.codigo, self.nombre)

    class Admin:
        pass
    class Meta:
        unique_together = ('codigo', 'nombre')


class Profesor(models.Model):
    ci = models.IntegerField(max_length=8, unique=True)
    nombre = models.CharField(max_length=20)
    telefono = models.CharField(blank=True, help_text='Debe\
    estar en formato XXXX-XXXXXXX o XXXXXXX', max_length=12)
    email = models.EmailField()
    oficina = models.CharField(max_length=15, blank=True)
    dpto = models.ForeignKey(Departamento)

    def __unicode__(self):
        return 'Prof. %s' % self.nombre

    class Meta:
        verbose_name_plural = "Profesores"
        unique_together = ('ci', 'nombre')

    class Admin:
        pass
